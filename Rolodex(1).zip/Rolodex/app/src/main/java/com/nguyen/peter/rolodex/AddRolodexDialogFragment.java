package com.nguyen.peter.rolodex;


import android.annotation.SuppressLint;

@SuppressLint("ValidFragment")
public class AddRolodexDialogFragment extends RolodexDialogFragmentBase
{
    public AddRolodexDialogFragment(MainActivityFragment mainActivityFragment)
    {
        super(true, mainActivityFragment);
    }
}
