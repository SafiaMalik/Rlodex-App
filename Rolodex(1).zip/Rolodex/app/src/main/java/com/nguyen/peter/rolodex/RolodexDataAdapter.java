package com.nguyen.peter.rolodex;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;


public class RolodexDataAdapter extends BaseAdapter
{
    private ArrayList<Rolodex> rolodexArrayList;
    private LayoutInflater layoutInflater;

    private TextView getTextView(View view, int textViewId)
    {
        return (TextView) view.findViewById(textViewId);
    }

    public RolodexDataAdapter(Context context, ArrayList<Rolodex> dataList)
    {
        this.rolodexArrayList = dataList;
        this.layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount()
    {
        return ((null != this.rolodexArrayList) ? this.rolodexArrayList.size() : 0);
    }

    @Override
    public Object getItem(int i)
    {
        if ((null != this.rolodexArrayList) && !this.rolodexArrayList.isEmpty())
        {
            if ((i >= 0) && (i < this.rolodexArrayList.size()))
                return this.rolodexArrayList.get(i);
        }

        return null;
    }

    @Override
    public long getItemId(int i)
    {
        return i;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup container)
    {
        if (null == convertView)
        {
            convertView = this.layoutInflater.inflate(R.layout.rolodex_list_row, null);
            if (null == convertView)
                return null;
        }

        TextView textViewName = (TextView) convertView.findViewById(R.id.textViewName);
        TextView textViewPhone = (TextView) convertView.findViewById(R.id.textViewPhone);

        Rolodex rolodex = (Rolodex) this.getItem(position);
        if (null != rolodex)
        {
            textViewName.setText(rolodex.getFullName());
            textViewPhone.setText(rolodex.PhoneNumber);
            convertView.setTag(rolodex);
        }
        else
        {
            convertView.setTag(null);
        }

        return convertView;
    }
}
