package com.nguyen.peter.rolodex;

import android.annotation.SuppressLint;
import android.content.DialogInterface;

@SuppressLint("ValidFragment")
public class MessageDialogFragment extends MessageDialogFragmentBase
{
    public MessageDialogFragment(String title, String msg, ButtonGroupType buttonGroupType)
    {
        super(title, msg, buttonGroupType);
    }

    @Override
    protected void onClickPossitiveButton(DialogInterface dialogInterface, int i)
    {
        super.onClickPossitiveButton(dialogInterface, i);
    }

    @Override
    protected void onClickNegativeButton(DialogInterface dialogInterface, int i)
    {
        super.onClickNegativeButton(dialogInterface, i);
    }
}
