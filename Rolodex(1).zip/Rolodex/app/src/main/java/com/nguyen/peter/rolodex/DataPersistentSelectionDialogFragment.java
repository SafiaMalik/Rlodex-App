package com.nguyen.peter.rolodex;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;


@SuppressLint("ValidFragment")
public class DataPersistentSelectionDialogFragment extends DialogFragment
{
    private MainActivityFragment mainActivityFragment;

    public DataPersistentSelectionDialogFragment(MainActivityFragment activityFragment)
    {
        super();
        this.mainActivityFragment = activityFragment;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.data_persistent_selection);
        int checkedRadioButtonIndex = (this.mainActivityFragment.isSharedPreferencesUsed() ? 0 : 1);
        builder.setSingleChoiceItems(R.array.settings_items,
                checkedRadioButtonIndex,
                new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int selectedButtonIndex)
                    {
                        switch (selectedButtonIndex)
                        {
                            case 0:         // Use SharedPreferences.
                                DataPersistentSelectionDialogFragment.this.mainActivityFragment.setUseSharedPreferences(true);
                                break;

                            case 1:         // Use database.
                                DataPersistentSelectionDialogFragment.this.mainActivityFragment.setUseSharedPreferences(false);
                                break;
                        }
                    }
                });

        builder.setNegativeButton(R.string.cancel_button, null);
        builder.setPositiveButton(R.string.ok_button,
                new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i)
                    {
                        DataPersistentSelectionDialogFragment.this.mainActivityFragment.reloadRolodex();
                    }
                });

        return builder.create();
    }
}
