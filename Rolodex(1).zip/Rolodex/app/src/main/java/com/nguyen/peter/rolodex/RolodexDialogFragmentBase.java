package com.nguyen.peter.rolodex;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import android.view.View;
import android.widget.EditText;

import java.util.ArrayList;


@SuppressLint("ValidFragment")
public class RolodexDialogFragmentBase extends DialogFragment
{
    private EditText editTextFirstName;
    private EditText editTextLastName;
    private EditText editTextMiddleName;
    private EditText editTextPhoneNumber;

    private int updateRolodexIndex;

    protected MainActivityFragment mainActivityFragment;

    protected String FirstName;
    protected String LastName;
    protected String MiddleName;
    protected String PhoneNumber;

    protected boolean bAddMode;


    protected RolodexDialogFragmentBase(boolean bAddMode, MainActivityFragment mainActivityFragment)
    {
        super();

        this.bAddMode = bAddMode;
        this.mainActivityFragment = mainActivityFragment;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View dialogView = getActivity().getLayoutInflater().inflate(R.layout.rolodex_dialog_fragment, null);
        builder.setView(dialogView);

        builder.setTitle(this.bAddMode ? R.string.add_rolodex : R.string.update_rolodex);

        this.editTextFirstName = (EditText) dialogView.findViewById(R.id.editTextFirstName);
        this.editTextLastName = (EditText) dialogView.findViewById(R.id.editTextLastName);
        this.editTextMiddleName = (EditText) dialogView.findViewById(R.id.editTextMiddleName);
        this.editTextPhoneNumber = (EditText) dialogView.findViewById(R.id.editTextPhoneNumber);

        if (!this.bAddMode)
        {
            this.editTextFirstName.setText(this.FirstName);
            this.editTextLastName.setText(this.LastName);
            this.editTextMiddleName.setText(this.MiddleName);
            this.editTextPhoneNumber.setText(this.PhoneNumber);

            ArrayList<Rolodex> dataArrayList = this.mainActivityFragment.getRolodexData();
            this.updateRolodexIndex = -1;
            for (int i = 0; i < dataArrayList.size(); i++)
            {
                Rolodex rolodex = dataArrayList.get(i);
                if ((rolodex.FirstName == this.FirstName) &&
                    (rolodex.LastName == this.LastName) &&
                    (rolodex.MiddleName == this.MiddleName) &&
                    (rolodex.PhoneNumber == this.PhoneNumber))
                {
                    this.updateRolodexIndex = i;
                    break;
                }
            }
        }

        builder.setPositiveButton(R.string.ok_button, new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialogInterface, int i)
            {
                Rolodex rolodex = new Rolodex();

                rolodex.FirstName = RolodexDialogFragmentBase.this.editTextFirstName.getText().toString();
                rolodex.LastName = RolodexDialogFragmentBase.this.editTextLastName.getText().toString();
                rolodex.MiddleName = RolodexDialogFragmentBase.this.editTextMiddleName.getText().toString();
                rolodex.PhoneNumber = RolodexDialogFragmentBase.this.editTextPhoneNumber.getText().toString();

                if (RolodexDialogFragmentBase.this.bAddMode)
                    RolodexDialogFragmentBase.this.mainActivityFragment.addRolodexRecord(rolodex);
                else
                    RolodexDialogFragmentBase.this.mainActivityFragment.updateRolodexRecord(RolodexDialogFragmentBase.this.updateRolodexIndex, rolodex);
            }
        });

        builder.setNegativeButton(R.string.cancel_button, new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialogInterface, int i)
            {

            }
        });

        return builder.create();
    }

}
