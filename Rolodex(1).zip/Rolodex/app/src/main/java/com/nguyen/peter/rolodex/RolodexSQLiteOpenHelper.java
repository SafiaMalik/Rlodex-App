package com.nguyen.peter.rolodex;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class RolodexSQLiteOpenHelper extends SQLiteOpenHelper
{
    public static final String TABLE_ROLODEX = "Rolodex";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_FIRSTNAME = "first_name";
    public static final String COLUMN_LASTNAME = "last_name";
    public static final String COLUMN_MIDDLENAME = "middle_name";
    public static final String COLUMN_PHONENUMBER = "phone_number";

    private static final String DATABASE_NAME = "rolodex.db";
    private static final int DATABASE_VERSION = 1;

    // Database creation sql statement
    private static final String DATABASE_CREATE =
            "create table " + TABLE_ROLODEX + "( " +
                COLUMN_ID + " integer primary key autoincrement, " +
                COLUMN_FIRSTNAME + " text not null, " +
                COLUMN_LASTNAME + " text not null, " +
                COLUMN_MIDDLENAME + " text, " +
                COLUMN_PHONENUMBER + " text not null" +
            ");";

    public RolodexSQLiteOpenHelper(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase)
    {
        sqLiteDatabase.execSQL(DATABASE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion)
    {
        String warningMessage = String.format("Upgrading database from V%d to V%d, which will destroy all old data",
                                              oldVersion,
                                              newVersion);
        Log.w(RolodexSQLiteOpenHelper.class.getName(), warningMessage);

        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_ROLODEX);
        onCreate(sqLiteDatabase);
    }
}
