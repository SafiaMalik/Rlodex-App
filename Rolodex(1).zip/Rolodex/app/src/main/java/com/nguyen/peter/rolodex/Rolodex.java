package com.nguyen.peter.rolodex;


public class Rolodex
{
    public String FirstName;
    public String LastName;
    public String MiddleName;
    public String PhoneNumber;

    public Rolodex()
    {
        this.FirstName = "";
        this.LastName = "";
        this.MiddleName = "";
        this.PhoneNumber = "";
    }


    public String getFullName()
    {
        if ((null == this.MiddleName) || this.MiddleName.isEmpty())
             return String.format("%s, %s", this.LastName, this.FirstName);
        else return String.format("%s, %s %s", this.LastName, this.FirstName, this.MiddleName);
    }
}
