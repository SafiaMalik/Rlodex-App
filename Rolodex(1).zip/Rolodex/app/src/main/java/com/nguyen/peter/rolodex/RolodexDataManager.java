package com.nguyen.peter.rolodex;


import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class RolodexDataManager
{
    private final static String RolodexSharedPreferencesName = "Rolodex";
    private final static String FirstNameKeyPrefix = "FirstName";
    private final static String LastNameKeyPrefix = "LastName";
    private final static String MiddleNameKeyPrefix = "MiddleName";
    private final static String PhoneNumberPrefix = "PhoneNumber";
    private final static String RolodexItemCount = "RolodexItemCount";

    private SQLiteDatabase sqLiteDatabase;
    private RolodexSQLiteOpenHelper rolodexSQLiteOpenHelper;
    private SharedPreferences sharedPreferences;
    private Context context;

    private boolean bUseSharedPreferences;


    public RolodexDataManager(Context context)
    {
        this.context = context;
        this.sharedPreferences = context.getSharedPreferences(RolodexDataManager.RolodexSharedPreferencesName, Context.MODE_PRIVATE);
        this.bUseSharedPreferences = false;
        this.rolodexSQLiteOpenHelper = new RolodexSQLiteOpenHelper(context);
        this.sqLiteDatabase = null;
    }

    public void setUseSharedPreferences(boolean flag)
    {
        this.bUseSharedPreferences = flag;
        if (false == flag)
        {
            if (null == this.sqLiteDatabase)
                this.sqLiteDatabase = this.rolodexSQLiteOpenHelper.getWritableDatabase();
        }
    }

    public boolean IsSharedPreferencesUsed()
    {
        return this.bUseSharedPreferences;
    }

    public void updateRolodexDatabase(ArrayList<Rolodex> dataArrayList)
    {
        if (this.bUseSharedPreferences)
        {
            String keyName;
            Rolodex rolodex;

            SharedPreferences.Editor editor = this.sharedPreferences.edit();
            editor.clear();

            editor.putInt(RolodexDataManager.RolodexItemCount, dataArrayList.size());
            for (int i = 0; i < dataArrayList.size(); i++)
            {
                rolodex = dataArrayList.get(i);

                keyName = String.format("%s%d", RolodexDataManager.FirstNameKeyPrefix, i);
                editor.putString(keyName, rolodex.FirstName);

                keyName = String.format("%s%d", RolodexDataManager.LastNameKeyPrefix, i);
                editor.putString(keyName, rolodex.LastName);

                keyName = String.format("%s%d", RolodexDataManager.MiddleNameKeyPrefix, i);
                editor.putString(keyName, rolodex.MiddleName);

                keyName = String.format("%s%d", RolodexDataManager.PhoneNumberPrefix, i);
                editor.putString(keyName, rolodex.PhoneNumber);
            }

            editor.commit();
        }
        else
        {
            if (null == this.sqLiteDatabase)
                this.sqLiteDatabase = this.rolodexSQLiteOpenHelper.getWritableDatabase();
            this.sqLiteDatabase.execSQL(String.format("DELETE FROM %s", RolodexSQLiteOpenHelper.TABLE_ROLODEX));

            for (int i = 0; i < dataArrayList.size(); i++)
            {
                Rolodex rolodex = dataArrayList.get(i);
                ContentValues values = new ContentValues();
                values.put(RolodexSQLiteOpenHelper.COLUMN_FIRSTNAME, rolodex.FirstName);
                values.put(RolodexSQLiteOpenHelper.COLUMN_LASTNAME, rolodex.LastName);
                values.put(RolodexSQLiteOpenHelper.COLUMN_MIDDLENAME, rolodex.MiddleName);
                values.put(RolodexSQLiteOpenHelper.COLUMN_PHONENUMBER, rolodex.PhoneNumber);
                long insertId = this.sqLiteDatabase.insert(RolodexSQLiteOpenHelper.TABLE_ROLODEX,
                                                           null,
                                                           values);
            }
        }
    }

    public ArrayList<Rolodex> getRolodexFromDatabase()
    {
        ArrayList<Rolodex> dataArrayList = new ArrayList<Rolodex>();

        if (this.bUseSharedPreferences)
        {
            int itemCount = 0;
            if (this.sharedPreferences.contains(RolodexDataManager.RolodexItemCount))
            {
                itemCount = this.sharedPreferences.getInt(RolodexDataManager.RolodexItemCount, 0);
                for (int i = 0; i < itemCount; i++)
                {
                    Rolodex rolodex = new Rolodex();

                    String keyName;
                    keyName = String.format("%s%d", RolodexDataManager.FirstNameKeyPrefix, i);
                    if (this.sharedPreferences.contains(keyName))
                        rolodex.FirstName = this.sharedPreferences.getString(keyName, "");

                    keyName = String.format("%s%d", RolodexDataManager.LastNameKeyPrefix, i);
                    if (this.sharedPreferences.contains(keyName))
                        rolodex.LastName = this.sharedPreferences.getString(keyName, "");

                    keyName = String.format("%s%d", RolodexDataManager.MiddleNameKeyPrefix, i);
                    if (this.sharedPreferences.contains(keyName))
                        rolodex.MiddleName = this.sharedPreferences.getString(keyName, "");

                    keyName = String.format("%s%d", RolodexDataManager.PhoneNumberPrefix, i);
                    if (this.sharedPreferences.contains(keyName))
                        rolodex.PhoneNumber = this.sharedPreferences.getString(keyName, "");

                    dataArrayList.add(rolodex);
                }
            }
        }
        else
        {
            if (null == this.sqLiteDatabase)
                this.sqLiteDatabase = this.rolodexSQLiteOpenHelper.getWritableDatabase();

            Cursor cursor = this.sqLiteDatabase.query(RolodexSQLiteOpenHelper.TABLE_ROLODEX,
                                                        new String[]
                                                                {
                                                                    RolodexSQLiteOpenHelper.COLUMN_FIRSTNAME,
                                                                    RolodexSQLiteOpenHelper.COLUMN_LASTNAME,
                                                                    RolodexSQLiteOpenHelper.COLUMN_MIDDLENAME,
                                                                    RolodexSQLiteOpenHelper.COLUMN_PHONENUMBER
                                                                },
                                                        null,
                                                        null,
                                                        null,
                                                        null,
                                                        null);

            int colIndex;
            cursor.moveToFirst();
            while (!cursor.isAfterLast())
            {
                Rolodex rolodex = new Rolodex();

                colIndex = cursor.getColumnIndex(RolodexSQLiteOpenHelper.COLUMN_FIRSTNAME);
                rolodex.FirstName = cursor.getString(colIndex);

                colIndex = cursor.getColumnIndex(RolodexSQLiteOpenHelper.COLUMN_LASTNAME);
                rolodex.LastName = cursor.getString(colIndex);

                colIndex = cursor.getColumnIndex(RolodexSQLiteOpenHelper.COLUMN_MIDDLENAME);
                rolodex.MiddleName = cursor.getString(colIndex);

                colIndex = cursor.getColumnIndex(RolodexSQLiteOpenHelper.COLUMN_PHONENUMBER);
                rolodex.PhoneNumber = cursor.getString(colIndex);

                dataArrayList.add(rolodex);

                cursor.moveToNext();
            }

            cursor.close();
        }

        return dataArrayList;
    }

    public RolodexDataAdapter createRolodexDataAdapter(ArrayList<Rolodex> dataArrayList)
    {
        RolodexDataAdapter dataAdapter = new RolodexDataAdapter(this.context, dataArrayList);
        return dataAdapter;
    }

    public RolodexDataAdapter createRolodexDataAdapter()
    {
        ArrayList<Rolodex> dataArrayList = this.getRolodexFromDatabase();
        return this.createRolodexDataAdapter(dataArrayList);
    }
}
