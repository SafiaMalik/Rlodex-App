package com.nguyen.peter.rolodex;

import android.annotation.SuppressLint;
import android.content.DialogInterface;


@SuppressLint("ValidFragment")
public class ConfirmDataDeletionMessageDialogFragment extends MessageDialogFragmentBase
{
    private MainActivityFragment mainActivityFragment;

    public void setMainActivityFragment(MainActivityFragment mainActivityFragment)
    {
        this.mainActivityFragment = mainActivityFragment;
    }

    public ConfirmDataDeletionMessageDialogFragment(String title, String msg, ButtonGroupType buttonGroupType)
    {
        super(title, msg, buttonGroupType);
        this.mainActivityFragment = null;
    }

    @Override
    protected void onClickPossitiveButton(DialogInterface dialogInterface, int i)
    {
        super.onClickPossitiveButton(dialogInterface, i);
        if (null != this.mainActivityFragment)
            this.mainActivityFragment.deleteSelectedRolodexRecord();
    }

    @Override
    protected void onClickNegativeButton(DialogInterface dialogInterface, int i)
    {
        super.onClickNegativeButton(dialogInterface, i);
    }
}
