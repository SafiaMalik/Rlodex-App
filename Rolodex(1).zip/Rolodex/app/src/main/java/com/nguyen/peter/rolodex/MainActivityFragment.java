package com.nguyen.peter.rolodex;

import androidx.fragment.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;


public class MainActivityFragment extends Fragment
{
    private ListView listViewRolodex;
    private RolodexDataManager rolodexDataManager;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_main, container, false);

        // This fragment has menu items to display
        setHasOptionsMenu(true);

        this.rolodexDataManager = new RolodexDataManager(getActivity());

        this.listViewRolodex = (ListView) view.findViewById(R.id.listViewRolodex);
        this.listViewRolodex.setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
        this.listViewRolodex.setAdapter(this.rolodexDataManager.createRolodexDataAdapter());
        this.listViewRolodex.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
            {
                // Mark this view row as selected.
                view.setSelected(true);
            }
        });

        return view;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater)
    {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.app_menu, menu);
    }

    public ArrayList<Rolodex> getRolodexData()
    {
        return this.rolodexDataManager.getRolodexFromDatabase();
    }

    public void reloadRolodex()
    {
        ArrayList<Rolodex> dataArrayList = getRolodexData();
        this.listViewRolodex.setAdapter(this.rolodexDataManager.createRolodexDataAdapter(dataArrayList));
    }

    public void addRolodexRecord(Rolodex rolodex)
    {
        ArrayList<Rolodex> dataArrayList = this.getRolodexData();
        dataArrayList.add(rolodex);
        this.rolodexDataManager.updateRolodexDatabase(dataArrayList);
        this.listViewRolodex.setAdapter(this.rolodexDataManager.createRolodexDataAdapter(dataArrayList));
    }

    public void updateRolodexRecord(int position, Rolodex rolodex)
    {
        ArrayList<Rolodex> dataArrayList = this.getRolodexData();
        dataArrayList.set(position, rolodex);
        this.rolodexDataManager.updateRolodexDatabase(dataArrayList);
        this.listViewRolodex.setAdapter(this.rolodexDataManager.createRolodexDataAdapter(dataArrayList));
    }

    public void deleteSelectedRolodexRecord()
    {
        int selectedPosition = this.listViewRolodex.getCheckedItemPosition();
        ArrayList<Rolodex> dataArrayList = this.getRolodexData();
        dataArrayList.remove(selectedPosition);
        this.rolodexDataManager.updateRolodexDatabase(dataArrayList);
        this.listViewRolodex.setAdapter(this.rolodexDataManager.createRolodexDataAdapter(dataArrayList));
    }

    public void setUseSharedPreferences(boolean flag)
    {
        this.rolodexDataManager.setUseSharedPreferences(flag);
    }

    public boolean isSharedPreferencesUsed()
    {
        return this.rolodexDataManager.IsSharedPreferencesUsed();
    }

    // Handle choice from options menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Switch based on the MenuItem id
        switch (item.getItemId())
        {
            case R.id.settings_menu:
                {
                    DataPersistentSelectionDialogFragment dlg = new DataPersistentSelectionDialogFragment(this);
                    dlg.show(getFragmentManager(), "settings");
                }
                return true;

            case R.id.add_menu:
                {
                    AddRolodexDialogFragment dlg = new AddRolodexDialogFragment(this);
                    dlg.show(getFragmentManager(), "add_rolodex");
                }
                return true; // Consume the menu event

            case R.id.update_menu:
                {
                    int selectedPosition = this.listViewRolodex.getCheckedItemPosition();
                    Rolodex selectedIem = (Rolodex) this.listViewRolodex.getAdapter().getItem(selectedPosition);
                    if (null != selectedIem)
                    {
                        UpdateRolodexDialogFragment dlg = new UpdateRolodexDialogFragment(selectedIem, this);
                        dlg.show(getFragmentManager(), "update_rolodex");
                    }
                    else
                    {
                        MessageDialogFragment msgDlg = new MessageDialogFragment(getResources().getString(R.string.error),
                                                                                 getResources().getString(R.string.no_selected_item),
                                                                                 MessageDialogFragmentBase.ButtonGroupType.OK);
                        msgDlg.show(getFragmentManager(), "error");
                    }
                }
                return true; // Consume the menu event

            case R.id.delete_menu:
                {
                    int selectedPosition = this.listViewRolodex.getCheckedItemPosition();
                    Rolodex selectedIem = (Rolodex) this.listViewRolodex.getAdapter().getItem(selectedPosition);
                    if (null != selectedIem)
                    {
                        ConfirmDataDeletionMessageDialogFragment msgDlg = new ConfirmDataDeletionMessageDialogFragment(getResources().getString(R.string.confirmation),
                                                                                                                       getResources().getString(R.string.confirm_deleting_selected_item),
                                                                                                                       MessageDialogFragmentBase.ButtonGroupType.YES_NO);
                        msgDlg.setMainActivityFragment(this);
                        msgDlg.show(getFragmentManager(), "confirm");
                    }
                }
                return true; // Consume the menu event

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
