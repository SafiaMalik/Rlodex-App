package com.nguyen.peter.rolodex;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import static com.nguyen.peter.rolodex.MessageDialogFragmentBase.ButtonGroupType.*;


@SuppressLint("ValidFragment")
public class MessageDialogFragmentBase extends DialogFragment
{
    private String message;
    private String title;
    private ButtonGroupType buttonGroupType;
    private SelectedButtonType selectedButtonType;

    public MessageDialogFragmentBase(String title, String msg, ButtonGroupType buttonGroupType)
    {
        super();

        this.title = title;
        this.message = msg;
        this.buttonGroupType = buttonGroupType;
        switch (this.buttonGroupType)
        {
            case OK_CANCEL:
                this.selectedButtonType = SelectedButtonType.CANCEL;
                break;

            case YES_NO:
                this.selectedButtonType = SelectedButtonType.NO;
                break;

            case OK:
            default:
                this.selectedButtonType = SelectedButtonType.OK;
                break;
        }
    }

    protected SelectedButtonType getSelectedButtonType()
    {
        return this.selectedButtonType;
    }

    protected void onClickPossitiveButton(DialogInterface dialogInterface, int i)
    {

    }

    protected void onClickNegativeButton(DialogInterface dialogInterface, int i)
    {

    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(this.title);
        builder.setMessage(this.message);

        int positiveButtonStringId;
        int negativeButtonStringId = R.string.cancel_button;
        switch (this.buttonGroupType)
        {
            case OK_CANCEL:
                {
                    positiveButtonStringId = R.string.ok_button;
                    negativeButtonStringId = R.string.cancel_button;
                }
                break;

            case YES_NO:
                {
                    positiveButtonStringId = R.string.yes_button;
                    negativeButtonStringId = R.string.no_button;
                }
                break;

            case OK:
            default:
                {
                    positiveButtonStringId = R.string.ok_button;
                }
                break;
        }

        builder.setPositiveButton(positiveButtonStringId, new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialogInterface, int i)
            {
                switch (MessageDialogFragmentBase.this.buttonGroupType)
                {
                    case OK_CANCEL:
                        MessageDialogFragmentBase.this.selectedButtonType = MessageDialogFragmentBase.SelectedButtonType.OK;
                        break;

                    case YES_NO:
                        MessageDialogFragmentBase.this.selectedButtonType = MessageDialogFragmentBase.SelectedButtonType.YES;
                        break;

                    case OK:
                    default:
                        MessageDialogFragmentBase.this.selectedButtonType = MessageDialogFragmentBase.SelectedButtonType.OK;
                        break;
                }

                onClickPossitiveButton(dialogInterface, i);
            }
        });

        if ((OK_CANCEL == this.buttonGroupType) || (YES_NO == this.buttonGroupType))
        {
            builder.setNegativeButton(negativeButtonStringId, new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialogInterface, int i)
                {
                    switch (MessageDialogFragmentBase.this.buttonGroupType)
                    {
                        case OK_CANCEL:
                            MessageDialogFragmentBase.this.selectedButtonType = MessageDialogFragmentBase.SelectedButtonType.CANCEL;
                            break;

                        case YES_NO:
                            MessageDialogFragmentBase.this.selectedButtonType = MessageDialogFragmentBase.SelectedButtonType.NO;
                            break;

                        case OK:
                        default:
                            MessageDialogFragmentBase.this.selectedButtonType = MessageDialogFragmentBase.SelectedButtonType.OK;
                            break;
                    }

                    onClickNegativeButton(dialogInterface, i);
                }
            });
        }

        return builder.create();
    }

    public enum ButtonGroupType
    {
        OK,
        OK_CANCEL,
        YES_NO
    }

    public enum SelectedButtonType
    {
        OK,
        CANCEL,
        YES,
        NO,
    }
}
