package com.nguyen.peter.rolodex;


import android.annotation.SuppressLint;

@SuppressLint("ValidFragment")
public class UpdateRolodexDialogFragment extends RolodexDialogFragmentBase
{
    public UpdateRolodexDialogFragment(Rolodex rolodexToUpdate, MainActivityFragment mainActivityFragment)
    {
        super(false, mainActivityFragment);

        super.FirstName = rolodexToUpdate.FirstName;
        super.LastName = rolodexToUpdate.LastName;
        super.MiddleName = rolodexToUpdate.MiddleName;
        super.PhoneNumber = rolodexToUpdate.PhoneNumber;
    }
}
